# UGOT word commands

The robot's camera reads text. When it sees one of your command words it
moves: forward, backward, turn, or strafe, either until the word is gone or
for a set time / distance / angle.

## Setup

1. Install uv: https://docs.astral.sh/uv/getting-started/installation/
2. Unzip this folder, open a terminal in it, and run the window:

   ```bash
   uv run word_commands/text_rec_gui.py
   ```

   The first run downloads Python 3.13+ (if needed) and the dependencies.
   Always start it through `uv run`; plain `python` doesn't have the
   dependencies.

## Using it

- Your computer must be on the same network as the robot.
- Set **Robot IP** to your robot's address, then edit the word table
  (Add word / Remove).
- **Save** writes the settings into `word_commands/text_rec.py`.
  **Save & Run** also starts the robot; **Stop** stops it. The camera shows
  on the right and the robot's output in the log underneath.
- To run without the window: `uv run word_commands/text_rec.py`
  (opens its own camera window; press `q` there to quit).
